function scoreSpam(text) {
 const t=String(text).toLowerCase().replace(/ё/g,'е');
 const rules=[[/анонимн\w*\s+сообщени|анонимное сообщение|узнать отправителя|посмотреть отправителя|кто тебе написал/u,4,'анонимные сообщения'],[/промокод|бонус|бесплатн\w*\s+(?:приз|подарок)|розыгрыш|выигрыш|скидка/u,2,'рекламные слова'],[/казино|ставки на спорт|фрибет|депозит|tastydrop/u,3,'игровая реклама'],[/перейди\s+по\s+ссылке|забери\s+бонус|получи\s+приз/u,2,'призыв перейти'],[/все еще тебя люблю|я тебя никогда не прощу/u,1,'типовая приманка']];
 let score=0, reasons=[]; for(const [re,n,label] of rules) if(re.test(t)){score+=n;reasons.push(label)} return {score,reasons};
}
if(typeof module!=='undefined')module.exports=scoreSpam;
